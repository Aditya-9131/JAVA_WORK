public class q1 {
    public static void main(String[] args) {
        int[] array1 = {1, 5, 6, 7};
        int[] array2 = {2, 4, 8, 10};
        
        int[] finalArray = mergeArray(array1, array2);
        
        System.out.print("FinalArray = {");
        for (int i = 0; i < finalArray.length; i++) {
            System.out.print(finalArray[i]);
            if (i < finalArray.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("}");
    }
    
    private static int[] mergeArray(int[] arr1, int[] arr2) {
        int[] result = new int[arr1.length + arr2.length];
        int i = 0, j = 0, k = 0;
        
        while (i < arr1.length && j < arr2.length) {
            if (arr1[i] <= arr2[j]) {
                result[k++] = arr1[i++];
            } else {
                result[k++] = arr2[j++];
            }
        }
        
        while (i < arr1.length) {
            result[k++] = arr1[i++];
        }
        
        while (j < arr2.length) {
            result[k++] = arr2[j++];
        }
        
        return result;
    }
}
