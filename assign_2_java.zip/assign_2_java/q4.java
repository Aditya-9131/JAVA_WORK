import java.util.Scanner;

public class q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of test cases: ");
        int numTestCases = scanner.nextInt();

        int[][] testCases = new int[numTestCases][];
        
        for (int i = 0; i < numTestCases; i++) {
            System.out.print("Enter the number of elements for test case " + (i + 1) + ": ");
            int numElements = scanner.nextInt();
            testCases[i] = new int[numElements];
            
            System.out.println("Enter the elements for test case " + (i + 1) + ":");
            for (int j = 0; j < numElements; j++) {
                testCases[i][j] = scanner.nextInt();
            }
        }

        int totalOddCount = 0;
        int totalEvenCount = 0;
        
        for (int[] testCase : testCases) {
            int oddCount = 0;
            int evenCount = 0;
            
            for (int num : testCase) {
                if (num % 2 == 0) {
                    evenCount++;
                } else {
                    oddCount++;
                }
            }
            
            totalOddCount += oddCount;
            totalEvenCount += evenCount;
            
            System.out.println("Test Case: Odd = " + oddCount + ", Even = " + evenCount);
        }
        
        System.out.println("Overall: Odd = " + totalOddCount + ", Even = " + totalEvenCount);

        scanner.close();
    }
}
