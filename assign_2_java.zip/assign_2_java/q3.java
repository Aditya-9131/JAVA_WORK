import java.util.Scanner;

public class q3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] inputArray = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            inputArray[i] = scanner.nextInt();
        }

        moveZerosToEnd(inputArray);

        System.out.print("Final Array: {");
        for (int i = 0; i < n; i++) {
            System.out.print(inputArray[i]);
            if (i < n - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("}");

        scanner.close();
    }

    private static void moveZerosToEnd(int[] arr) {
        int nonZeroIndex = 0;

        // Move all non-zero elements to the left and maintain the position for the next non-zero element
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0) {
                arr[nonZeroIndex++] = arr[i];
            }
        }

        // Fill the remaining positions with zeros
        while (nonZeroIndex < arr.length) {
            arr[nonZeroIndex++] = 0;
        }
    }
}
