import java.util.Scanner;

public class q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in array1: ");
        int n1 = scanner.nextInt();
        int[] array1 = readArray(scanner, n1);
        
        System.out.print("Enter the number of elements in array2: ");
        int n2 = scanner.nextInt();
        int[] array2 = readArray(scanner, n2);
        
        System.out.print("Enter the number of elements in array3: ");
        int n3 = scanner.nextInt();
        int[] array3 = readArray(scanner, n3);
        
        int[] commonElements = findCommonElements(array1, array2, array3);
        System.out.print("Final Array = {");
        for (int i = 0; i < commonElements.length; i++) {
            System.out.print(commonElements[i]);
            if (i < commonElements.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("}");
        
        scanner.close();
    }
    
    private static int[] readArray(Scanner scanner, int n) {
        int[] array = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }
        return array;
    }
    
    private static int[] findCommonElements(int[] arr1, int[] arr2, int[] arr3) {
        int[] result = new int[Math.min(Math.min(arr1.length, arr2.length), arr3.length)];
        int i = 0, j = 0, k = 0, count = 0;
        
        while (i < arr1.length && j < arr2.length && k < arr3.length) {
            if (arr1[i] == arr2[j] && arr2[j] == arr3[k]) {
                result[count++] = arr1[i];
                i++;
                j++;
                k++;
            } else if (arr1[i] < arr2[j]) {
                i++;
            } else if (arr2[j] < arr3[k]) {
                j++;
            } else {
                k++;
            }
        }
        
        int[] commonElements = new int[count];
        System.arraycopy(result, 0, commonElements, 0, count);
        
        return commonElements;
    }
}
