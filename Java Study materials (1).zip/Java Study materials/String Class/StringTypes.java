package MyPackage;

public class StringTypes {
	public static void main(String[] args) {
		String s1=new String ("Hello");	//Created from a set of chars
		System.out.println("First string = " +s1);
		
		String s2=new String();
		System.out.println("Second string = " +s2);
		
		String s3=new String(s1);
		System.out.println("Third string = " +s3);
		
		char[] charArray= {'A', 'R', 'I', 'J', 'I', 'T'};
		String s4=new String(charArray);
		System.out.println("Fourth string = " +s4);
		
		//String s5=new String(charArray, 0, 3);
		//System.out.println("Fifth string = " +s5);
		
	}

}
