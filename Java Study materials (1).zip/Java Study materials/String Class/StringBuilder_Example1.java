package MyPackage;

public class StringBuilder_Example1 {

	public static void main(String[] args) {
		StringBuilder  str=new StringBuilder();
		str.append("String added");
		
		System.out.println("String = "+str.toString());

		StringBuilder str1=new StringBuilder("Hello World");
		System.out.println("String1 = "+str1.toString());
		
		StringBuilder str2=new StringBuilder(10);
		System.out.println("Capacity = "+str2.capacity());
	
		StringBuilder str3=new StringBuilder(str.toString());
		//System.out.println("String3 = "+str3.toString())
	
	}

}
