package MyPackage;

public class StringBuilder_Example2 {
	public static void main(String[] args) {
		StringBuilder str=new StringBuilder("Hello World");
		
		//Method 1 : reverse() --> To reverse the string
		//StringBuilder reverseStr=str.reverse();
		//System.out.println("Reversed string = "+reverseStr.toString());
		
		//Method 2 : codePointAt(index) --->returns unicode value of a char
		StringBuilder str2=new StringBuilder("BDZK");
		//System.out.println(" code point = "+str2.codePointAt(0));
		//System.out.println(" code point = "+str2.codePointBefore(2));
		//Method 3 : appendCodePoint(int codePoint) (44 represents ,)
		StringBuilder str3=new StringBuilder("Arijit");
		System.out.println(" After appending codepoint = "+str3.appendCodePoint(44));
	
		//Method 4 : delete and replace
		//StringBuilder str4=new StringBuilder("hello");
		//System.out.println("Method 4 = "+str4);
		
		//str4.insert(5, "World");
		//System.out.println("Method 4 after insert = "+str4);
		
		//str4.append(" Hi");
		//System.out.println("Method 4 after appending = "+str4);
		
		//str4.delete(2, 5);
		//System.out.println("Method 4 after deleting 2, 5  = "+str4);
		
		//str4.deleteCharAt(2);
		//System.out.println("Method 4 after deleting char at index 2  = "+str4);
		
		//str4.replace(7, 9, "IIITG");
		//System.out.println("Method 4 after replacing with new string  = "+str4);
		
	}


}
