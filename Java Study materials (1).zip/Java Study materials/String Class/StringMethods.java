package MyPackage;

public class StringMethods {
	public static void main(String[] args) {
		String s =new String ("Hello");
		
		int i=s.length();
		System.out.println(i);
		
		//char ch = s.charAt(1);
		//System.out.println(ch);
		
		String s1=s.substring(0,3);
		System.out.println(s1);
		
		String s2=s.toUpperCase();
		System.out.println(s2);
		
		System.out.println(s.toUpperCase().contains("EL"));
		
	
	}

}
