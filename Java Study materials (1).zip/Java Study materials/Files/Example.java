package MyPackage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Example {
	public static void main(String[] args){
		//Creating a file
		/*
		 * File f=new File("Test.txt"); try { f.createNewFile(); } catch (IOException e)
		 * { e.printStackTrace(); }
		 */
		
		//Writing some lines to the created file
		
		
		/*
		 * try { FileWriter f = new FileWriter("Test.txt");
		 * f.write("Writing the first line\nSecond line"); f.close();
		 * 
		 * } catch (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		 
		//Reading lines from the created file
		
		 File f=new File("Test.txt"); 
		 
		try {
			Scanner sc = new Scanner(f);
			while(sc.hasNextLine()) 
			{ 
				System.out.println(sc.nextLine()); 
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		}
		 
			
	}


