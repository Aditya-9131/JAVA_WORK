package MyPackage;

import java.io.BufferedReader;

public class ExampleBufferedReader {

	public static void main(String[] args) {
		
		InpurStreamReader
		BufferedReader in=new BufferedReader();
		
	}

}
