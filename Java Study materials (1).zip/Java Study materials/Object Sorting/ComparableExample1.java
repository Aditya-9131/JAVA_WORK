package MyPackage;
import java.util.*;

class Student implements Comparable<Student>{
	int roll;
	String name;
	String birthYear;
	
	Student(int roll, String name, String birthYear){
		this.roll=roll;
		this.name=name;
		this.birthYear=birthYear;
	}
	
	public int compareTo(Student s) {
		int thisBirth=Integer.parseInt(this.birthYear);
		int thatBirth=Integer.parseInt(s.birthYear);
		
		if(thisBirth<thatBirth)
		{
			return -1;
		}
		else if (thisBirth>thatBirth)
		{
			return 1;
		}
		else
			return 0;
		
	}

	@Override
	public String toString() {
		return "Roll = "+this.roll+" Name = "+this.name+ " Year = "+this.birthYear;
	}

}

public class ComparableExample1 {
	public static void main(String[] args) {
		ArrayList<Student> stud=new ArrayList<Student>();
		stud.add(new Student(101, "Harry", "1995"));
		stud.add(new Student(103, "Alex", "1990"));
		stud.add(new Student(105, "John", "1987"));
		
		Collections.sort(stud);
		
		for(Student s: stud)
		{
			System.out.println(s);
		}

		
	
	}

}
