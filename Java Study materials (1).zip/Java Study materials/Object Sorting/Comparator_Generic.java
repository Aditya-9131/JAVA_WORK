//This is Generic style of object sorting sorting. We need to create different class for
//implementing the comparator interface which contains() compare method

package MyPackage;
//import java.lang.*;
import java.util.*;

class Student1{
	int roll;
	int age;
	String name;
	
	Student1(int roll, int age, String name){
		this.roll=roll;
		this.age=age;
		this.name=name;
	}
	
	@Override
	public String toString() {
		return "Name = "+this.name+" Roll No = "+this.roll+" Age = "+this.age;
	}
}

class AgeComparator implements Comparator<Student1>{
	public int compare(Student1 s1, Student1 s2) {
		if(s1.age>s2.age) {return 1;}
		else if (s1.age<s2.age){return -1;}
		else return 0;
	}
}

class NameComparator implements Comparator<Student1>{
	public int compare(Student1 s1, Student1 s2) {
		return (s1.name.compareTo(s2.name));
	}
}

public class Comparator_Generic {
	public static void main(String[] args) {
		ArrayList<Student1> stud=new ArrayList<Student1>();
		stud.add(new Student1(105, 25, "Harry"));
		stud.add(new Student1(111, 23, "Rose"));
		stud.add(new Student1(101, 22, "Alex"));
		
		System.out.println("Before sorting...");
		
		for(int i=0; i<stud.size(); i++) {
			System.out.println(stud.get(i));
		}
		
		Collections.sort(stud, new AgeComparator());
		
		System.out.println("\nAfter sorting by age...");
		
		for(int i=0; i<stud.size(); i++) {
			System.out.println(stud.get(i));
		}

		Collections.sort(stud, new NameComparator());
		
		System.out.println("\nAfter sorting by name...");
		
		for(int i=0; i<stud.size(); i++) {
			System.out.println(stud.get(i));
		}

	
	}

}
